export const surfbar = `
<div id="addon-ui-qc8h3xz">
    <div class="progress-container-qc8h3xz">
        <div class="progress-bar-qc8h3xz bg-color-qc8h3xz">
            <div class="progress-qc8h3xz progress-bar-color-qc8h3xz">
                <div class="progress-count-qc8h3xz"></div>
            </div>
        </div>
        <div id="hub-container-qc8h3xz" class="animation-target-qc8h3xz">
            <div id="hub-qc8h3xz">
                <button class='button-qc8h3xz paused-qc8h3xz'></button>
                <span class="btp-points-qc8h3xz">
                    <i class="fa fa-spinner fa-spin"></i>
                </span>
                <a class="font-awesome-color-qc8h3xz report-qc8h3xz">
                    <i class="fa fa-exclamation report-exclamation-qc8h3xz"></i>
                </a>
            </div>
        </div>
    </div>
</div>
`