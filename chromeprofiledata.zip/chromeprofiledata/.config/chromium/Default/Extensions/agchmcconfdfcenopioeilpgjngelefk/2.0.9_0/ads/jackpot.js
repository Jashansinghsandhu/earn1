
function Jackpot() {
    this.filledAreas = [];
}

let TASK_TYPE_ICON = "ICON";
let SHOW_ICONS_AFTER_SECONDS = 6;

let jackpotIconClassName = generateRandomString(32);

Jackpot.prototype.insertIconTasks = function (surfbar) {
    let jackpotContext = this;

    setTimeout(function () {
        if (!surfbar.isTasksShown || surfbar.isOneTaskClicked || surfbar.isSameHostName) {
            jackpotContext.insertIconTaskNodes(surfbar);
            jackpotContext.randomizePositions(surfbar);
            jackpotContext.addTaskClickedListener(surfbar);

            chrome.runtime.sendMessage({
                from: "jackpot",
                action: "updateIsTasksShown",
                surfbar: surfbar
            });
        }

    }, SHOW_ICONS_AFTER_SECONDS * 1000);
};

Jackpot.prototype.getSvg = function (cointyp, width=80, height=80) {
    if (cointyp === undefined) cointyp = "gold";

    let img = document.createElement('img');
    img.classList.add("svg-icon", jackpotIconClassName);
    img.width = width;
    img.height = height;
    img.style.cssText = `width: ${width}px !important; height: ${height}px !important;`;
    img.src = chrome.runtime.getURL(`../resources/icons/coin_star_${cointyp}.svg`);

    return img;
};

Jackpot.prototype.randomizePositions = function (surfbar) {
    this.filledAreas.splice(0, this.filledAreas.length);

    let self = this;

    setTimeout(function () {
        let svgIcons = $('.svg-icon');
        let jackpotSelector = $(svgIcons.first()).parent().attr("selector");
        let jackpotSelectorElements = getJackpotSelectorElements(jackpotSelector);
        if (jackpotSelectorElements !== null) {
            svgIcons.each(function (idx, svgIcon) {
                let random = Math.floor(Math.random() * jackpotSelectorElements.length);
                let randomElement = jackpotSelectorElements.splice(random, 1);
                if (randomElement.length === 0) {
                    return;
                }

                let rearrangedSvgIconArea = rearrangeSvgIcon(svgIcons[idx], randomElement);
                let isSvgRearranged = rearrangedSvgIconArea !== undefined;
                $(svgIcon).parent().attr("is-svg-rearranged", isSvgRearranged);
                if (isSvgRearranged) {
                    self.filledAreas.push(rearrangedSvgIconArea);
                }
            });
        }

        distributeIcons(self, surfbar);

        showSvgIcons(svgIcons);

    }, 1000);

    return false;
};

Jackpot.prototype.calculateOverlap = function (area1) {
    let overlap = 0;
    for (let i = 0; i < this.filledAreas.length; i++) {

        let area2 = this.filledAreas[i];

        if (area1.x + area1.width < area2.x) {
            continue;
        }
        if (area2.x + area2.width < area1.x) {
            continue;
        }
        if (area1.y + area1.height < area2.y) {
            continue;
        }
        if (area2.y + area2.height < area1.y) {
            continue;
        }

        let x1 = Math.max(area1.x, area2.x);
        let y1 = Math.max(area1.y, area2.y);
        let x2 = Math.min(area1.x + area1.width, area2.x + area2.width);
        let y2 = Math.min(area1.y + area1.height, area2.y + area2.height);

        overlap += ((x1 - x2) * (y1 - y2));
    }

    return overlap;
};

Jackpot.prototype.insertIconTaskNodes = function (surfbar) {
    if (surfbar.tasks == null) {
        return;
    }

    let maxPoints = 0;

    surfbar.tasks.forEach(function (task) {
        if (task.taskType === TASK_TYPE_ICON) {
            if (task.earnedPoints > maxPoints) maxPoints = task.earnedPoints
        }
    });

    surfbar.tasks.forEach(function (task) {

        if (task.taskType === TASK_TYPE_ICON) {
            let div = $('<div/>', {
                siteid: surfbar.params.siteid,
                viewCode: surfbar.params.code,
                taskCode: task.code,
                taskPoints: task.earnedPoints,
                userId: task.userId,
                selector: surfbar.params.jackpotSelector,
                html: new Jackpot().getSvg(coinRank(maxPoints, task.earnedPoints)),
                css: {
                    "z-index": 2147483647
                }
            });
            $("html").append(div);
        }
    });
};

Jackpot.prototype.addTaskClickedListener = function (surfbar) {
    $(document).on('click', `.${jackpotIconClassName}`, function (e) {

        let svg = $(this);
        let div = $(this).parent();
        let taskCode = $(div).attr("taskCode");

        $(svg).hide();
        $(svg).attr("clicked", true);

        let element = document.elementFromPoint(e.pageX - window.pageXOffset, e.pageY - window.pageYOffset);
        if (element !== null) {
            if ($(element).is("video")) {
                if (element.playing) {
                    element.pause();
                } else {
                    element.play();
                }
            } else {
                element.click();
            }
        }

        chrome.runtime.sendMessage({
            from: "jackpot",
            action: "oneTaskClicked",
            surfbar: surfbar,
        });

        if (surfbar.params.isDemo) {
            handleClickSuccess(surfbar, svg);
        } else {
            $.ajax({
                type: "POST",
                url: surfbar.confirmTasksForViewUrl,
                data: {
                    siteId: $(div).attr("siteid"),
                    viewCode: $(div).attr("viewCode"),
                    taskCode: taskCode,
                    userId: $(div).attr("userId"),
                    amount: $(div).attr("taskPoints"),
                },
                success: function () {
                    handleClickSuccess(surfbar, svg);
                },
                error: function (xhr) {
                    $(svg).stop(true, true);
                    console.debug(xhr.responseText);
                }
            });
        }
    });
};

function coinRank(maxPoints, points) {
    let percent = (points / maxPoints) * 100

    if (percent >= 66.66) {
        return 'gold'
    } else if (percent >= 33.33) {
        return 'silver'
    } else {
        return 'copper'
    }
}

function distributeIcons(context, surfbar) {
    let svgWidth = 100;
    let svgHeight = 70;
    let maxSearchIterations = 10;
    let min_x = 0;
    let min_y = 0;

    let max_x = window.innerWidth - (2 * svgWidth);
    let body = document.body;
    let html = document.documentElement;
    let max_y = Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight) - (2 * svgHeight);

    if (max_y > 5000) {
        max_y = 2000;
    }


    let svgIcons = $('.svg-icon');
    let taskCount = surfbar.tasks ? surfbar.tasks.length : 0;
    let insertedTasks = 0;
    $(svgIcons).each(function (idx, svgIcon) {
        insertedTasks++;

        let isSvgRearranged = $(svgIcon).parent().attr("is-svg-rearranged");
        let isMaximumTasksReached = insertedTasks > taskCount;
        if (isSvgRearranged || isMaximumTasksReached) {
            return;
        }

        let rand_x = 0;
        let rand_y = 0;
        let smallestOverlap = 9007199254740992;
        let bestChoice;
        let area;

        for (let i = 0; i < maxSearchIterations; i++) {
            rand_x = Math.round(min_x + ((max_x - min_x) * (Math.random() % 1)));
            rand_y = Math.round(min_y + ((max_y - min_y) * (Math.random() % 1)));
            area = {
                x: rand_x,
                y: rand_y,
                width: $(this).width(),
                height: $(this).height()
            };

            let overlap = context.calculateOverlap(area);
            if (overlap < smallestOverlap) {
                smallestOverlap = overlap;
                bestChoice = area;
            }
            if (overlap === 0) {
                break;
            }
        }

        context.filledAreas.push(bestChoice);

        $(this).css({
            position: "absolute",
            "z-index": 2147483647,
            left: rand_x,
            top: rand_y,
            display: "none"
        });

        $(this).attr("pos-x", rand_x);
        $(this).attr("pos-y", rand_y);
    });
}

function showConfirmedTaskPoints(svgNode) {
    let divSvg = $(svgNode).parent();
    let taskPoints = $(divSvg).attr("taskPoints");
    let offsetPoints = 200

    let divConfirmed = $('<div/>', {
        html: "+" + taskPoints,
        class: "get-points-qc8h3xz",
        css: {
            "position": $(svgNode).css("position"),
            "margin": $(svgNode).css("margin"),
            "left": $(svgNode).css("left"),
            "top": $(svgNode).css("top")
        }
    });
    divSvg.append(divConfirmed);

    divConfirmed.animate({top: parseInt($(svgNode).css("top").split("px")[0]) - offsetPoints + "px", opacity: 0}, 2000);
}

function showSvgIcons(svgIcons) {
    svgIcons.each(function (idx, svgIcon) {
        blinkIcon(idx, $(svgIcon));
    });
}

function rearrangeSvgIcon(svgIcon, randomElement) {
    let offset = $(randomElement).offset();

    $(svgIcon).css({
        position: "absolute",
        "z-index": 2147483647,
        left: offset.left,
        top: offset.top,
        display: "none"
    });

    $(svgIcon).attr("pos-x", offset.left);
    $(svgIcon).attr("pos-y", offset.top);

    return {
        x: offset.left,
        y: offset.top,
        width: $(svgIcon).width(),
        height: $(svgIcon).height()
    };
}

function getJackpotSelectorElements(selector) {
    if (!selector) {
        return null;
    }

    let elements;

    elements = $("a[href^='" + selector + "']");
    if (elements.length !== 0) {
        return elements;
    }

    try {
        elements = $("#" + selector);
        if (elements.length !== 0) {
            return elements;
        }

        elements = $("." + selector);
        if (elements.length !== 0) {
            return elements;
        }
    } catch (e) {

    }

    return null;
}

function blinkIcon(secondsHidden, element) {
    blink(element, 0, secondsHidden);

    setTimeout(function () {
        let counter = 0;

        let interval = setInterval(function () {
            let isClicked = $(element).attr("clicked");
            let isSvgRearranged = $(element).parent().attr("is-svg-rearranged");

            if (isClicked) {
                return;
            }

            $(element).fadeOut(1, function () {
                if (isSvgRearranged) {
                    return;
                }

                let randomX = Math.floor(Math.random() * 51) - 25;
                let randomY = Math.floor(Math.random() * 51) - 25;

                let posX = parseInt($(element).attr("pos-x"));
                let posY = parseInt($(element).attr("pos-y"));

                $(element).css({
                    left: posX + randomX,
                    top: posY + randomY,
                });
            });

            $(element).delay(500).fadeIn(1);

            if (++counter === 3) {
                clearInterval(interval);
                hide(element, 3);
            }
        }, 3000);
    }, secondsHidden * 1000);

}

function blink(element, secondsShown, secondsHidden) {
    $(element)
        .delay(secondsShown * 1000).fadeOut(1)
        .delay(secondsHidden * 1000).fadeIn(1);
}

function hide(element, delayInSeconds) {
    element.delay(delayInSeconds * 1000).fadeOut(1, function () {
        let divSvgNode = $(element).parent()[0];
        $(divSvgNode).remove();
    });
}

function isValidURL(url) {
    let pattern = new RegExp('^(https?:\\/\\/)?' + 
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + 
        '((\\d{1,3}\\.){3}\\d{1,3}))' + 
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + 
        '(\\?[;&a-z\\d%_.~+=-]*)?' + 
        '(\\#[-a-z\\d_]*)?$', 'i'); 

    return !!pattern.test(url);
}

function handleClickSuccess(surfbar, svg) {
    let div = $(svg).parent();
    let taskCode = $(div).attr("taskCode");

    $(svg).stop(true, true);
    $(svg).fadeOut(1, function () {
        showConfirmedTaskPoints(svg);
    });

    surfbar.earnedTaskPoints += parseFloat($(div).attr("taskPoints"));
    console.debug("Earned Task Points: " + surfbar.earnedTaskPoints);

    chrome.runtime.sendMessage({
        from: "jackpot",
        action: "removeTask",
        surfbar: surfbar,
        taskCode: taskCode,
    });
}

function generateRandomString(length) {
    let result = '';
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }

    return result;
}

Object.defineProperty(HTMLMediaElement.prototype, 'playing', {
    get: function () {
        return !!(this.currentTime > 0 && !this.paused && !this.ended && this.readyState > 2);
    }
});
